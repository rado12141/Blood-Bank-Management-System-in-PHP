<footer class="foter">
            <b>Made By: <a href="http://freeprojectscodes.com">Yugesh Verma</a></b>
            <br>
            &COPY;
</footer>



</body>
</html>
